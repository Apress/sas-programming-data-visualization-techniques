library(Hmisc)
library(lattice)
library(grDevices)
sasdata <- sasxport.get('c:/temp/r', method=('csv'))
trellis.device(jpeg, file='c:/temp/r/program.jpg', width=480, height=480)
trellis.par.set(theme=col.whitebg())
trellis.par.set('background',list(col='white'))
trellis.par.set('plot.symbol',list(col='blue'))
trellis.par.set('dot.symbol',list(col='blue'))
trellis.par.set('axis.line',list(col='red'))
trellis.par.set('box.rectangle',list(col='red'))
trellis.par.set('par.xlab.text',list(col='green'))
trellis.par.set('par.ylab.text',list(col='green'))
trellis.par.set('par.zlab.text',list(col='green'))
trellis.par.set('axis.text',list(col='green'))
xyplot(actual ~ yq | product*cntry
      ,data=sasdata$prdsale
      ,xlab = 'Quarter'
      ,ylab = 'Actual Sales'
      ,panel = function(x, y) {
                               panel.grid(h=-1, v=-1)
                               panel.xyplot(x, y)
                               panel.loess(x, y
                                          ,span=1
                                          ,degree=2
                                          )
                              }
      ,main = 'Plotted using R'
      )
dev.off()
q()
